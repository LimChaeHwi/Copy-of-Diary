package com.exam;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.imageio.ImageIO;
import javax.media.jai.JAI;
import javax.media.jai.RenderedOp;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.google.gson.Gson;


@WebServlet("/FileUploadServlet") 
public class FileUploadServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@Override
	protected void doPost(
			HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");
		
		// JSON
		//TODO: Iframe JSON 
		//response.setContentType("application/json; charset=UTF-8"); 
		//response.setContentType("text/plain; charset=UTF-8");
		
		//Iframe  application/json
		//
		// Content-type  text/plain or text/html 
		
		//System.out.println(request.getHeader("accept"));
		if (request.getHeader("accept").indexOf("application/json") != -1) {
	        response.setContentType("application/json; charset=UTF-8");
	    } else {
	        // IE workaround
	        response.setContentType("text/plain; charset=UTF-8");
	    }		
		
		PrintWriter out = response.getWriter();
		
		RequestModel model = new RequestModel();
		
		try {
				//디스크상의 프로젝트 실제 경로얻기, 서버의 저장 경로
			String contextRootPath = this.getServletContext().getRealPath("/");	
				//"C:\\Bigdata\\html\\Diary\\WebContent\\";	//이클립스의 저장 경로
				//1. 메모리나 파일로 업로드 파일 보관하는 FileItem의 Factory 설정
			DiskFileItemFactory diskFactory = new DiskFileItemFactory(); 
				//디스크 파일 아이템 공장, 일시적인 저장장소를 지정.
			diskFactory.setRepository(new File(contextRootPath + "/WEB-INF/temp"));
				//2. 업로드 요청을 처리하는 ServletFileUpload 생성
			ServletFileUpload upload = new ServletFileUpload(diskFactory); 
			upload.setSizeMax(10 * 1024 * 1024); //10MB : 전체 최대 업로드 파일 크기
				//upload.setFileSizeMax(10 * 1024 * 1024); //10MB : 
			
				//3. 업로드 요청 파싱해서 FileItem목록 구함
				//request로 전달되어 온 multipart/form-data를 RFC1867에 준하는 형태로 변경.
			@SuppressWarnings("unchecked")
			List<FileItem> items = upload.parseRequest(request); 
			
			for(FileItem item : items) {			//배열의 항목수 만큼 변수에 자동 대입
				
				//4. FileItem이 폼 입력 항목인지 여부에 따라 알맞은 처리
				if (item.isFormField()) { 			//파일이 아닌경우	(true:simple form field)
					processFormField(model, item);	//메소드 호출						
				} else { 							//파일인 경우
					if(item.getSize()!=0) { //false:uploadfile
						//실제 업로드 메소드 호출
						processUploadFile(model, item, contextRootPath);
					}														
				}			
			}
			
			Gson gson = new Gson();
			String outString = gson.toJson(model);
				//System.out.println(outString);
			out.print(outString);			
			
		} catch(Exception e) {	
			
			e.printStackTrace();
			
			out.print("{\"result\":\"500\"");
			out.print(",\"msg\":\""+e.getMessage());			
			out.print("\"}");				
		}
	}

	//업로드한 정보가 파일인 경우 처리
	private void processUploadFile(
			RequestModel model, FileItem item, String contextRootPath) throws Exception {
		
		String name = item.getFieldName(); 			//파일의 필드 이름 얻기
		String fileName = item.getName(); 			//파일명 얻기
		String contentType = item.getContentType(); //컨텐츠 타입 얻기
		long fileSize = item.getSize(); 			//파일의 크기 얻기
		
			//업로드 파일명을 현재시간으로 변경 후 저장 UUID universally unique identifier /lastIndexOf(".") 마지막 '.'인 인덱스 반환.
		String uploadedFileName = System.currentTimeMillis() 
				+ UUID.randomUUID().toString() +fileName.substring(fileName.lastIndexOf("."));
		//저장할 절대 경로로 파일 객체 생성
		
		File uploadedFile = new File(contextRootPath + "/upload/" + uploadedFileName); 
			//write(uploadedFile) disk에 upload된 아이템을 저장함.
		item.write(uploadedFile); //파일 저장

		FileInfoModel fileInfoModel = new FileInfoModel(name, fileName, 
				                                       uploadedFileName, fileSize, contentType);
			//request로 전달된 데이터가 photo인지 file인지 판별.
		if("photo".equals(name)) {
			List<FileInfoModel> photoList = model.getPhoto();
			if(photoList == null ) photoList = new ArrayList<FileInfoModel>();
			photoList.add(fileInfoModel);
			model.setPhoto(photoList);
		} else if("file".equals(name)) {
			model.setFile(fileInfoModel);
		}

			//썸네일 만들기 (불러올 파일의 디렉토리와 파일명, 섬네일 이미지 저정 장소, zoom크기)
		ThumbnailImage(contextRootPath+"/upload/"+uploadedFileName, contextRootPath+"/thumbnail/"+uploadedFileName, 2);
		item.delete();
	}
	
		//업로드된 것이 파일이 아닌 경우 처리
	private void processFormField(RequestModel model, FileItem item) throws Exception{
		String name = item.getFieldName();
		String value = item.getString("UTF-8");
		
			//(RequestModel)
		if("title".equals(name)) {
			model.setTitle(value);
		} else if("description".equals(name)) {
			model.setDescription(value);
		}
	}
		//섬네일 이미지로 변환하여 저장. (불러올 파일의 디렉토리와 파일명, 섬네일 이미지 저정 장소, zoom크기)
	private void  ThumbnailImage(String load, String save, int zoom)throws IOException{
		File file = new File(save);	//썸네일 이미지 저장을 위한 File 메소드 생성
		RenderedOp rp = JAI.create("fileload", load);	//원본 사진을 스캔한다.
		BufferedImage im = rp.getAsBufferedImage();	//이미지정보를 im에 저장해둔다. 사선으로 읽어서 저장
		
		int width = im.getWidth()/zoom; 	//가로크기
		int height = im.getHeight()/zoom;	//세로크기
		//썸네일 이미지를 생성하는 공간 설정
		//가로와 세로 축소된 이미지에 rgb색상으로 색을 넣는다. 축소된 공간을 만들어 준다.
		BufferedImage thumb = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);	
		//이미지 공간을 2D그래픽으로 처리
		Graphics2D ge = thumb.createGraphics();
		//썸네일 이미지 그리기
		ge.drawImage(im, 0, 0, width, height, null);	//그리기 단계 속성 없이 그려 넣는다.
		//썸네일 이미지 파일 포멧 설정 후 생성
		ImageIO.write(thumb, "jpg", file);	//thumb에 들어 있는 크기에 jpg형태로 만든다.
	}
	
}