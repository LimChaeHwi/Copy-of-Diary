package net.member.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.member.db.MemberDAO;

public class MemberFindFriendAction implements Action{
	@Override
	public ActionForward execute(HttpServletRequest request,HttpServletResponse response)throws Exception{
		
		HttpSession session = request.getSession();
		String id = (String)session.getAttribute("id");
		String friend_id = request.getParameter("friend_id");
		
		MemberDAO memberdao=new MemberDAO();
		
		String friend_name = memberdao.getFindFriend(friend_id);		//����Ʈ�� �޾ƿ�
		 
		request.setAttribute("friend_name", friend_name);		//ģ�� �̸�
		request.setAttribute("friend_id", friend_id);
		
		ActionForward forward=new ActionForward();
		forward.setRedirect(false);
		forward.setPath("./diarysharewrite.jsp");
		
		return forward;
	}
}
