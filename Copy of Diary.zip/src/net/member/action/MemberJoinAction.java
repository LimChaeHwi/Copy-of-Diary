package net.member.action;

import java.sql.Timestamp;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.member.db.MemberBean;
import net.member.db.MemberDAO;

public class MemberJoinAction implements Action{
	public String toKr(String value){
		String result= null;
		try{
			result = new String(value.getBytes("8859_1"), "utf-8");	//8859_1�������� �о�鿩�� utf-8�������� ��ȯ
		}catch(Exception e){}
		return result;
	}
	
	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)throws Exception{
		System.out.println(request.getParameter("name"));
		MemberDAO memberdao = new MemberDAO();
		MemberBean memberdata = new MemberBean();
		ActionForward forward = new ActionForward();
		
		boolean result = false;
		try{
			
			memberdata.setId(request.getParameter("id"));
			memberdata.setPassword(request.getParameter("password"));
			memberdata.setName(request.getParameter("name"));
			memberdata.setGender(request.getParameter("gender"));
			memberdata.setBirthday(request.getParameter("birthday"));
			memberdata.setBlood(request.getParameter("blood"));
			memberdata.setPhone(request.getParameter("phone"));
			memberdata.setAddress(request.getParameter("address"));
			memberdata.setEmail(request.getParameter("email"));
			memberdata.setJoindate(new Timestamp(System.currentTimeMillis()));
			
			result = memberdao.joinMember(memberdata);
			
			if(result==false){
				System.out.println("ȸ������ ����");
				forward.setRedirect(true);
				forward.setPath("./loginform.me");
				return forward;
			}
			System.out.println("ȸ�����Լ���");
			
			forward.setRedirect(true);
			forward.setPath("./loginform.me");
			return forward;
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return null;
	}	
}
