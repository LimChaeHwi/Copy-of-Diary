package net.member.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.member.db.MemberBean;
import net.member.db.MemberDAO;

public class MemberLoginAction implements Action{
	public String toKr(String value){
		String result= null;
		try{
			result = new String(value.getBytes("8859_1"), "utf-8");	//8859_1�������� �о�鿩�� utf-8�������� ��ȯ
		}catch(Exception e){}
		return result;
	}
	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)throws Exception{
		HttpSession session=request.getSession();
		MemberDAO memberdao = new MemberDAO();
		MemberBean memberdata = new MemberBean();
		ActionForward forward = new ActionForward();
		
		int result;
		
		try{
			memberdata.setId(request.getParameter("id"));
			memberdata.setPassword(request.getParameter("password"));
			
			result = memberdao.isMember(memberdata);
			
			if(result==-1){
				System.out.println("���������ʴ¾��̵�");
				response.setContentType("text/html;charset=utf-8");
				forward.setRedirect(true);
				forward.setPath("./loginform.me");
				return forward;
				//return null;
			}else if(result==0){
				System.out.println("��й�ȣƲ��");
				response.setContentType("text/html;charset=utf-8");
				forward.setRedirect(true);
				forward.setPath("./loginform.me");
				return forward;
			}else if(result==1){
			System.out.println("�α��μ���");
			session.setAttribute("id", memberdata.getId());
			session.setAttribute("name", memberdata.getName());
			forward.setRedirect(true);
			forward.setPath("./DiaryListAction.di");
			
			return forward;
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return null;
	}
}
