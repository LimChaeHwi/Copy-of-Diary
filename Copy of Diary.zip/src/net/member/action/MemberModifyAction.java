package net.member.action;

import java.sql.Timestamp;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.member.db.MemberBean;
import net.member.db.MemberDAO;

public class MemberModifyAction implements Action{
	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)throws Exception{
		MemberDAO memberdao = new MemberDAO();
		MemberBean memberdata = new MemberBean();
		ActionForward forward = new ActionForward();
		
		boolean result = false;
		try{
			
			memberdata.setImage(request.getParameter("image"));
			memberdata.setId(request.getParameter("id"));
			memberdata.setPassword(request.getParameter("password"));
			memberdata.setName(request.getParameter("name"));
			memberdata.setGender(request.getParameter("gender"));
			memberdata.setBirthday(request.getParameter("birthday"));
			memberdata.setBlood(request.getParameter("blood"));
			memberdata.setPhone(request.getParameter("phone"));
			memberdata.setAddress(request.getParameter("address"));
			memberdata.setEmail(request.getParameter("email"));
			memberdata.setJoindate(new Timestamp(System.currentTimeMillis()));
			
			result = memberdao.memberModify(memberdata);
			
			if(result==false){
				System.out.println("ȸ���������� ����");
				forward.setRedirect(true);
				forward.setPath("./DiaryListAction.di");
				return forward;
			}
			System.out.println("ȸ���������� ����");
			
			forward.setRedirect(true);
			forward.setPath("./DiaryListAction.di");
			return forward;
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return null;
	}	
}
