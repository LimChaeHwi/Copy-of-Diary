package net.member.action;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MemberFrontController extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet{
	/**
	 * 
	 */
	private static final long serialVersionUID = 2L;
	protected void doProcess(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		request.setCharacterEncoding("utf-8");
		String RequestURI = request.getRequestURI();			     //��û URI  /Diary/��û��
		String contextPath = request.getContextPath();			     //������Ʈ��  /Diary
		String command = RequestURI.substring(contextPath.length()); //            	 /��û��
		ActionForward forward = null;
		Action action = null;
		
		if(command.equals("/loginform.me")){
			forward = new ActionForward();
			forward.setRedirect(false);
			forward.setPath("./loginform.jsp");
		}
		else if(command.equals("/joinform.me")){
			forward = new ActionForward();
			forward.setRedirect(false);
			forward.setPath("./joinform.jsp");
		}
		else if(command.equals("/modify.me")){
			action=new MemberModify(); 
			try{
				forward=action.execute(request,response);
			}catch(Exception e){
				e.printStackTrace();
			}	
		}
		else if(command.equals("/login.me")){
			action=new MemberLoginAction();
			try{
				forward = action.execute(request, response);
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		
		else if(command.equals("/join.me")){
			action=new MemberJoinAction();
			try{
				forward = action.execute(request, response);
			}catch(Exception e){
				e.printStackTrace();
			}
		}	
		else if(command.equals("/MemberModifyAction.me")){
			action=new MemberModifyAction(); 
			try{
				forward=action.execute(request,response);
			}catch(Exception e){
				e.printStackTrace();
			}	
		}
		else if(command.equals("/MemberFindFriendAction.me")){
			action=new MemberFindFriendAction();
			try{
				forward=action.execute(request,response);
			}catch(Exception e){
				e.printStackTrace();
			}	
		}
		else if(command.equals("/MemberFindIdAction.me")){
			action=new MemberFindIdAction();
			try{
				forward=action.execute(request,response);
			}catch(Exception e){
				e.printStackTrace();
			}	
		}
		else if(command.equals("/MemberDeleteAction.me")){
			action=new MemberDeleteAction();
			try{
				forward=action.execute(request,response);
			}catch(Exception e){
				e.printStackTrace();
			}	
		}
		
		if(forward!=null){
			if(forward.isRedirect()){
				response.sendRedirect(forward.getPath());
			}else{
				RequestDispatcher dispatcher = 
						request.getRequestDispatcher(forward.getPath());
				dispatcher.forward(request, response);
			}
		}
	}
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		doProcess(request, response);
	}
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		doProcess(request, response);
	}
}
