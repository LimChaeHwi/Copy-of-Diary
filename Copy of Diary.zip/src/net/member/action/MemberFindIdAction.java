package net.member.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.member.db.MemberDAO;

public class MemberFindIdAction implements Action{
	@Override
	public ActionForward execute(HttpServletRequest request,HttpServletResponse response)throws Exception{
		
		String findid = null;
		String findpassword = null;
		if(request.getParameter("findid")!=null){
			findid = request.getParameter("findid");
		}
		String name = request.getParameter("name");
		String birthday = request.getParameter("birthday");
		
		MemberDAO memberdao=new MemberDAO();
		if(request.getParameter("findid")==null){
			findid = memberdao.getFindId(name, birthday);
			request.setAttribute("findid", findid);
			
			ActionForward forward=new ActionForward();
			forward.setRedirect(false);
			forward.setPath("./findresult.jsp?set="+1);
			return forward;
		}
		findpassword = memberdao.getFindPassword(findid, name, birthday);
		request.setAttribute("findpassword", findpassword);
		
		ActionForward forward=new ActionForward();
		forward.setRedirect(false);
		forward.setPath("./findresult.jsp?set="+2);
		return forward;
	}
}
