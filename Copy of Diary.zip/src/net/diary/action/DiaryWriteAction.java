package net.diary.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.diary.db.DiaryBean;
import net.diary.db.DiaryDAO;

public class DiaryWriteAction implements Action{
	
	public String toKr(String value){
		String result= null;
		try{
			result = new String(value.getBytes("8859_1"), "utf-8");	//8859_1�������� �о�鿩�� utf-8�������� ��ȯ
		}catch(Exception e){}
		return result;
	}
	@Override
	public ActionForward execute(HttpServletRequest request,HttpServletResponse response)throws Exception{
		
		DiaryDAO diarydao=new DiaryDAO();
		DiaryBean diarydata=new DiaryBean();
		ActionForward forward=new ActionForward();
		boolean result=false;
		
		try
		{

			diarydata.setDiary_id(request.getParameter("diary_id"));
			diarydata.setDiary_name(request.getParameter("diary_name"));
			diarydata.setDiary_type(request.getParameter("diary_type"));
			diarydata.setDiary_subject(request.getParameter("diary_subject"));
			diarydata.setDiary_content(request.getParameter("diary_content"));
			diarydata.setDiary_file(request.getParameter("diary_file"));
			diarydata.setDiary_weather(request.getParameter("diary_weather"));
			diarydata.setDiary_location(request.getParameter("diary_location"));
			diarydata.setWritedate(request.getParameter("writedate"));
			
			result=diarydao.diaryInsert(diarydata);
			
			if(result==false){
				System.out.println("�Խ��� ��� ����");
				return null;
			}
			System.out.println("�Խ��� ��� �Ϸ�");
			
			forward.setRedirect(true);
			forward.setPath("./DiaryDetailAction.di?num="+diarydata.getDiary_num());
			return forward;
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return null;
	}
}
