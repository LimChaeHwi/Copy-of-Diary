package net.diary.action;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.diary.db.DiaryDAO;
import net.member.db.MemberBean;
import net.member.db.MemberDAO;

public class DiaryShareListAction implements Action{
	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception{
		
		HttpSession session = request.getSession();
		String id = (String)session.getAttribute("id");
		
		DiaryDAO diarydao = new DiaryDAO();
		List diarysharelist = new ArrayList();
		
		String diary_share = request.getParameter("diary_share");
		String diary_sharename = request.getParameter("diary_sharename");
		
		
		int sharelistcount = diarydao.getShareListCount(id, diary_share);
		diarysharelist = diarydao.getDiaryShareList(id, diary_share);
		
		request.setAttribute("sharelistcount", sharelistcount);
		request.setAttribute("diarysharelist", diarysharelist);
		request.setAttribute("diary_share", diary_share);
		request.setAttribute("diary_sharename", diary_sharename);
		
		MemberDAO memberdao = new MemberDAO();
		MemberBean memberdata = new MemberBean();
		memberdata = memberdao.getProfile(id);
		request.setAttribute("memberdata", memberdata);
		
		ActionForward forward = new ActionForward();
		forward.setRedirect(false);
		forward.setPath("./diarysharelist.jsp");
		return forward;
	}
}
