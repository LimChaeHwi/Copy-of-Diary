package net.diary.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.diary.db.DiaryBean;
import net.diary.db.DiaryDAO;

public class DiaryShareAddAction implements Action{
	@Override
	public ActionForward execute(HttpServletRequest request,HttpServletResponse response)throws Exception{
			
		HttpSession session = request.getSession();
		String id = (String)session.getAttribute("id");
			DiaryDAO diarydao=new DiaryDAO();
			DiaryBean diarydata=new DiaryBean();
			ActionForward forward=new ActionForward();
			boolean result=false;
			try
			{
				
				diarydata.setDiary_id(request.getParameter("diary_id"));
				diarydata.setDiary_name(request.getParameter("diary_name"));
				diarydata.setDiary_type(request.getParameter("diary_type"));
				diarydata.setDiary_subject(request.getParameter("diary_subject"));
				diarydata.setDiary_content(request.getParameter("diary_content"));
				diarydata.setDiary_file(request.getParameter("diary_file"));
				diarydata.setDiary_weather(request.getParameter("diary_weather"));
				diarydata.setDiary_location(request.getParameter("diary_location"));
				diarydata.setWritedate(request.getParameter("writedate"));
				diarydata.setDiary_share(request.getParameter("diary_share"));
				diarydata.setDiary_sharename(request.getParameter("diary_sharename"));
				
				result=diarydao.diaryShareInsert(diarydata);
				
				if(result==false){
					System.out.println("�������̾ �߰� ����");
					return null; 
				}
				
				System.out.println("�������̾ �߰� �Ϸ�");
				
				forward.setRedirect(true);
				forward.setPath("./DiaryShareDetailAction.di?num="+diarydata.getDiary_num());
			//	forward.setPath("./DiaryShareListAction.di?diary_sharename="+diarydata.getDiary_sharename()+
			//			"&diary_share="+diarydata.getDiary_share());
				return forward;
			}catch(Exception ex){
				ex.printStackTrace();
			}
			return null;
	}

}

