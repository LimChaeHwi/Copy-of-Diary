package net.diary.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.diary.db.DiaryBean;
import net.diary.db.DiaryDAO;

public class DiaryModifyAction implements Action{
	public String toKr(String value){
		String result= null;
		try{
			result = new String(value.getBytes("8859_1"), "utf-8");	//8859_1�������� �о�鿩�� utf-8�������� ��ȯ
		}catch(Exception e){}
		return result;
	}
	@Override
	public ActionForward execute(HttpServletRequest request,HttpServletResponse response)throws Exception{
//		request.setCharacterEncoding("utf-8");	��ȯ�� �ȵ�
		HttpSession session=request.getSession();
		String id=(String)session.getAttribute("id");
		boolean result=false;
		
		int num=Integer.parseInt(request.getParameter("num"));
		
		DiaryDAO diarydao=new DiaryDAO();
		DiaryBean diarydata=new DiaryBean();
		ActionForward forward=new ActionForward();
		
		boolean usercheck=diarydao.isDiaryWriter(num, id);
		if(usercheck==false){
			response.setContentType("text/html;charset=utf-8");
			forward.setRedirect(true);
			forward.setPath("./DiaryListAction.di");
			
			return forward;
		}
		try{
			diarydata.setDiary_num(num);
			diarydata.setDiary_subject(request.getParameter("diary_subject"));
			diarydata.setDiary_type(request.getParameter("diary_type"));
			diarydata.setDiary_content(request.getParameter("diary_content"));

			result=diarydao.diaryModify(diarydata);
			
			if(result==false){
				System.out.println("���̾ ���� ����");
				return null;
			}
			System.out.println("���̾ ���� �Ϸ�");
			
			forward.setRedirect(true);
			forward.setPath("./DiaryDetailAction.di?num="+diarydata.getDiary_num());
			return forward;
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return null;
	}
	
}
