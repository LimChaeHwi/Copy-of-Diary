package net.diary.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.diary.db.DiaryBean;
import net.diary.db.DiaryDAO;

public class DiaryModifyView implements Action{
	
	@Override
	public ActionForward execute(HttpServletRequest request,HttpServletResponse response)throws Exception{
		
		ActionForward forward=new ActionForward();
		request.setCharacterEncoding("utf-8");
		
		DiaryDAO diarydao=new DiaryDAO();
		DiaryBean diarydata=new DiaryBean();
		
		int num=Integer.parseInt(request.getParameter("num"));
		diarydata=diarydao.getDetail(num);
		
		if(diarydata==null){
			System.out.println("(����)�󼼺��� ����");
			return null;
		}
		System.out.println("(����)�󼼺��� ����");
		
		request.setAttribute("diarydata", diarydata);
		
		forward.setRedirect(false);
		forward.setPath("./diarymodify.jsp");
		return forward;
	}

}
