package net.diary.action;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.diary.db.DiaryDAO;

public class DiaryMenuAction implements Action{
	@Override
	public ActionForward execute(HttpServletRequest request,HttpServletResponse response)throws Exception{
		HttpSession session = request.getSession();
		String id = (String)session.getAttribute("id");
//		String subject = (String)request.getAttribute("search_diary");
		
		DiaryDAO diarydao=new DiaryDAO();
		List diarylist=new ArrayList();
	
		int listcount=diarydao.getMenuCount(id);	//�� �޴� ���� �޾ƿ�
		diarylist=diarydao.getDiaryMenu(id);		//�޴��� �޾ƿ�

		request.setAttribute("listcount", listcount);		//�޴� ��
		request.setAttribute("diarylist", diarylist);		//���̾ �޴�
															//request��ü�� ���
		ActionForward forward=new ActionForward();
		forward.setRedirect(false);
		forward.setPath("./diarymenu.jsp");
		return forward;
	}
}
