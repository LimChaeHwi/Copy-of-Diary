package net.diary.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class DiaryDAO {
	Connection con;
	PreparedStatement pstmt;
	ResultSet rs;
	DataSource ds;
	
	public DiaryDAO(){
		try
		{
			Context init = new InitialContext();
		//	Context envCon = (Context) init.lookup("java:comp/env");
			ds = (DataSource)init.lookup("java:comp/env/jdbc/mysql"); //mysql
			con = ds.getConnection();
		}
		catch(Exception ex){
			System.out.println("DB���� ����:"+ex);
			return;
		}
	}
	private void close(ResultSet rs, PreparedStatement pstmt)
	{
		if(rs!=null)try{rs.close();}catch(SQLException ex){}
		if(pstmt!=null)try{pstmt.close();}catch(SQLException ex){}
	}
	//���� ���� ���ϱ�
	public int getListCount(String id){
		int x=0;
		try
		{
			pstmt=con.prepareStatement("select count(*) from diary where diary_id=? and diary_type!='undefined'");
			pstmt.setString(1, id);
			
			rs=pstmt.executeQuery();
			
			if(rs.next())
			{
				x=rs.getInt(1);
			}
		}
		catch(Exception ex){
			System.out.println("getListCount����:"+ex);
		}finally{
			close(rs,pstmt);
		}
		return x;
		
	}
	//�� ������ ����
	public int getMenuCount(String id){
		int x=0;
		try
		{
			pstmt=con.prepareStatement("select count(*) from (select distinct d1.diary_type from diary d1 where d1.diary_id=? and d1.diary_type!='undefined') d2");
			pstmt.setString(1, id);
			
			rs=pstmt.executeQuery();
			
			if(rs.next())
			{
				x=rs.getInt(1);
			}
		}
		catch(Exception ex){
			System.out.println("getMenuCount����:"+ex);
		}finally{
			close(rs,pstmt);
		}
		return x;
	//�� ��Ͽ��� �� ������ ���� �� ����	
	}public int getMenuDetailCount(String id, String diary_type){
		int x=0;
		try
		{
			pstmt=con.prepareStatement("select count(*) from diary where diary_id=? and diary_type=?");
			pstmt.setString(1, id);
			pstmt.setString(2, diary_type);
			
			rs=pstmt.executeQuery();
			
			if(rs.next())
			{
				x=rs.getInt(1);
			}
		}
		catch(Exception ex){
			System.out.println("getMenuCount����:"+ex);
		}finally{
			close(rs,pstmt);
		}
		return x;
		
	}
	//������ ����� �ο� �� ���ϱ�
	public int getShareCount(String id){
		int x=0;
		try
		{
			String sharecnt = "%"+id+"%";
			pstmt=con.prepareStatement("select count(*) from (select distinct d1.diary_share from diary d1 "
					+"where d1.diary_share like ? and d1.diary_type='undefined') d2"); 
			
			pstmt.setString(1, sharecnt);
			rs=pstmt.executeQuery();
			
			if(rs.next())
			{
				x = rs.getInt(1);
			}
		}
		catch(Exception ex){
			System.out.println("getShareCount����:"+ex);
		}finally{
			close(rs,pstmt);
		}
		return x;
		
	}
	//������ ������� �� ���� ���ϱ�
		public int getShareListCount(String id, String diary_share){
			int x=0;				
			try
			{
				String diary_share1 =null;
				String diary_share2 =null;
					if(diary_share.substring(0,id.length()).equals(id)){
						diary_share1=diary_share;
						diary_share2=diary_share.substring(diary_share.length()-id.length(),diary_share.length())+id;
					}else if(diary_share.substring(diary_share.length()-id.length(),diary_share.length()).equals(id)){
						diary_share1=id+diary_share.substring(0,id.length());
						diary_share2=diary_share;
					}
					
				pstmt=con.prepareStatement("select count(*) from (select d1.diary_share from diary d1 where d1.diary_share IN(?,?)) d2");
				pstmt.setString(1, diary_share1);
				pstmt.setString(2, diary_share2);
				
				rs=pstmt.executeQuery();
				
				if(rs.next())
				{
					x=rs.getInt(1);
				}
			}
			catch(Exception ex){
				System.out.println("getShareListCount����:"+ex);
			}finally{
				close(rs,pstmt);
			}
			return x;
			
		}
	//�� ��� ����
	public List getDiaryList(String id)
	{
		
		String diary_list_sql=
		"select @rownum := @rownum + 1 as rnum, d1.diary_num, d1.diary_id, d1.diary_name, d1.diary_type, d1.diary_subject,"+
		" substr(d1.diary_content,1,15), d1.diary_file, d1.diary_weather, d1.diary_location, d1.writedate from"+
		" (select * from diary d2 order by d2.diary_num desc) d1 where d1.diary_id=? and d1.diary_type!='undefined'";
		
		List list=new ArrayList();

		try
		{
			pstmt=con.prepareStatement(diary_list_sql);
			pstmt.setString(1, id);
			rs=pstmt.executeQuery();

			while(rs.next())
			{
				DiaryBean diarydata=new DiaryBean();
				
				diarydata.setDiary_num(rs.getInt("diary_num"));
				diarydata.setDiary_name(rs.getString("diary_name"));
				diarydata.setDiary_type(rs.getString("diary_type"));
				diarydata.setDiary_subject(rs.getString("diary_subject"));
				diarydata.setDiary_content(rs.getString("substr(d1.diary_content,1,15)"));
				diarydata.setDiary_file(rs.getString("diary_file"));
				diarydata.setDiary_weather(rs.getString("diary_weather"));
				diarydata.setDiary_location(rs.getString("diary_location"));
				diarydata.setWritedate(rs.getString("writedate"));
				list.add(diarydata);
				
			}
			
			return list;
			
		}catch(Exception ex){
			System.out.println("getDiaryList����:"+ex);
			
		}finally{
			close(rs,pstmt);
		}
		return null;
	}
	// �� ������ ���� ����Ʈ ����
	public List getDiaryMenu(String id)
	{
		String diary_list_sql=
		"select distinct diary_type from "+
		"diary where diary_id=? and diary_type!='undefined' order by diary_type asc";
		
		List list=new ArrayList();

		try
		{
			pstmt=con.prepareStatement(diary_list_sql);
			pstmt.setString(1, id);
			rs=pstmt.executeQuery();

			while(rs.next())
			{
				DiaryBean diarydata=new DiaryBean();
				diarydata.setDiary_type(rs.getString("diary_type"));
				
				list.add(diarydata);
			}
			return list;
			
		}catch(Exception ex){
			System.out.println("getDiaryMenu����:"+ex);
			
		}finally{
			close(rs,pstmt);
		}
		return null;
	}
	//�� ��Ͽ����� �� ����Ʈ ����
	public List getDiaryMenuDetail(String id,String diary_type)
	{
		String diary_list_sql="select * from"+
		"(select @rownum := @rownum+1 as rnum, d1.diary_num, d1.diary_id, d1.diary_name, d1.diary_type, d1.diary_subject,"+
		" d1.diary_content, d1.diary_file, d1.diary_weather, d1.diary_location, d1.writedate from"+
		" (select * from diary d2 order by d2.diary_num desc) d1 where d1.diary_id=? and d1.diary_type=?) d3";
		
		List list=new ArrayList();

		try
		{
			pstmt=con.prepareStatement(diary_list_sql);
			pstmt.setString(1, id);
			pstmt.setString(2, diary_type);
			rs=pstmt.executeQuery();
			
			while(rs.next())
			{
				DiaryBean diarydata=new DiaryBean();
				
				diarydata.setDiary_num(rs.getInt("diary_num"));
				diarydata.setDiary_name(rs.getString("diary_name"));
				diarydata.setDiary_type(rs.getString("diary_type"));
				diarydata.setDiary_subject(rs.getString("diary_subject"));
				diarydata.setDiary_content(rs.getString("diary_content"));
				diarydata.setDiary_file(rs.getString("diary_file"));
				diarydata.setDiary_weather(rs.getString("diary_weather"));
				diarydata.setDiary_location(rs.getString("diary_location"));
				diarydata.setWritedate(rs.getString("writedate"));
				list.add(diarydata);
				
			}
			return list;
			
		}catch(Exception ex){
			System.out.println("getDiaryList����:"+ex);
			
		}finally{
			close(rs,pstmt);
		}
		return null;
	}
	//������ ��� ��� ����
	public List getDiaryShare(String id)
		{
			
			String share = "%"+id+"%";
			String diary_list_sql=
				"select distinct diary_sharename, diary_share from "+
				"diary where diary_share like ? and diary_type='undefined' "+
				"order by diary_sharename asc";
			
			List list=new ArrayList();

			try
			{
				pstmt=con.prepareStatement(diary_list_sql);
				
				pstmt.setString(1, share);
				rs=pstmt.executeQuery();

				while(rs.next())
				{
					DiaryBean diarydata=new DiaryBean();
					
					diarydata.setDiary_sharename(rs.getString("diary_sharename"));
					diarydata.setDiary_share(rs.getString("diary_share"));
					list.add(diarydata);
					
				}
				return list;
				
			}catch(Exception ex){
				System.out.println("getDiaryShare����:"+ex);
				
			}finally{
				close(rs,pstmt);
			}
			return null;
		}
	//������ ������� �� ��� ����
		public List getDiaryShareList(String id, String diary_share)
			{
			String diary_share1 =null;
			String diary_share2 =null;
			if(diary_share.substring(0,id.length()).equals(id)){
				diary_share1=diary_share;
				diary_share2=diary_share.substring(diary_share.length()-id.length(),diary_share.length())+id;
			}else if(diary_share.substring(diary_share.length()-id.length(),diary_share.length()).equals(id)){
				diary_share1=id+diary_share.substring(0,id.length());
				diary_share2=diary_share;
			}
				String diary_list_sql=
					"select diary_num, diary_sharename, diary_name, diary_subject, diary_content, writedate from diary "+
					" where diary_share IN(?,?) "+
					" order by writedate desc";
					
				List list=new ArrayList();
				try
				{
					pstmt=con.prepareStatement(diary_list_sql);
					pstmt.setString(1, diary_share1);
					pstmt.setString(2, diary_share2);
					
					rs=pstmt.executeQuery();

					while(rs.next())
					{
						DiaryBean diarydata=new DiaryBean();
						diarydata.setDiary_num(rs.getInt("diary_num"));	
						diarydata.setDiary_sharename(rs.getString("diary_sharename"));
						diarydata.setDiary_name(rs.getString("diary_name"));
						diarydata.setDiary_subject(rs.getString("diary_subject"));
						diarydata.setDiary_content(rs.getString("diary_content"));
						diarydata.setWritedate(rs.getString("writedate"));
						list.add(diarydata);
						
					}
					return list;
						
				}catch(Exception ex){
					System.out.println("getDiaryShareList����:"+ex);
						
				}finally{
					close(rs,pstmt);
				}
				return null;
			}
	//�۳���� ����
	public DiaryBean getDetail(int num)throws Exception{
		DiaryBean diarydata=null;
		try
		{
			pstmt=con.prepareStatement("select * from diary where diary_num=?");
			pstmt.setInt(1, num);
			
			rs=pstmt.executeQuery();
			
			if(rs.next())
			{
				diarydata=new DiaryBean();
				
				diarydata.setDiary_num(rs.getInt("diary_num"));
				diarydata.setDiary_id(rs.getString("diary_id"));
				diarydata.setDiary_name(rs.getString("diary_name"));
				diarydata.setDiary_type(rs.getString("diary_type"));
				diarydata.setDiary_subject(rs.getString("diary_subject"));
				diarydata.setDiary_content(rs.getString("diary_content"));
				diarydata.setDiary_file(rs.getString("diary_file"));
				diarydata.setDiary_weather(rs.getString("diary_weather"));
				diarydata.setDiary_location(rs.getString("diary_location"));
				diarydata.setWritedate(rs.getString("writedate"));
			}
			return diarydata;
		}
		catch(Exception ex)
		{
			System.out.println("getDetail ����:"+ex);
		}
		finally
		{
			close(rs,pstmt);
		}
		return null;
	}
	//�� ���
	public boolean diaryInsert(DiaryBean diarydata){
		int num=0;
		String sql="";
		int result=0;
		
		try
		{
			pstmt=con.prepareStatement("select max(diary_num)from diary");
			rs=pstmt.executeQuery();
			
			if(rs.next())
				num=rs.getInt(1)+1;
			else
				num=1;
			diarydata.setDiary_num(num);
			sql=
				"insert into diary(diary_num, diary_id, diary_name, diary_type,";
			sql+="diary_subject, diary_content, diary_file,"+
					"diary_weather, diary_location, writedate) values(?,?,?,?,?,?,?,?,?,?)";
			
			pstmt=con.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.setString(2, diarydata.getDiary_id());
			pstmt.setString(3, diarydata.getDiary_name());
			pstmt.setString(4, diarydata.getDiary_type());
			pstmt.setString(5, diarydata.getDiary_subject());
			pstmt.setString(6, diarydata.getDiary_content());
			pstmt.setString(7, diarydata.getDiary_file());
			pstmt.setString(8, diarydata.getDiary_weather());
			pstmt.setString(9, diarydata.getDiary_location());
			pstmt.setString(10,diarydata.getWritedate());
			
			result=pstmt.executeUpdate();
			if(result==0)
				return false;
			
			return true;
		}
		catch(Exception ex){
			System.out.println("diaryInsert ����:"+ex);
		}
		finally
		{
			close(rs,pstmt);
		}
		return false;
	}
		//�� ����
	public boolean diaryModify(DiaryBean diarydata)throws Exception{
		String sql="update diary set diary_subject=?, diary_content=?"+
				" where diary_num=?";
		try
		{
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1, diarydata.getDiary_subject());
			pstmt.setString(2, diarydata.getDiary_content());
			pstmt.setInt(3, diarydata.getDiary_num());
			pstmt.executeUpdate();
			
			return true;
		}
		catch(Exception ex){
			System.out.println("diaryModify ����:"+ex);
		}
		finally
		{
			close(rs,pstmt);
		}
		return false;
	}
	//�� ����
	public boolean diaryDelete(int num){
		String diary_delete_sql="delete from diary where diary_num=?";
		int result=0;
		try
		{
			pstmt=con.prepareStatement(diary_delete_sql);
			pstmt.setInt(1, num);
			result=pstmt.executeUpdate();
			if(result==0)
				return false;
			return true;
		}
		catch(Exception ex){
			System.out.println("diaryDelete����:"+ex);
			
		}
		finally
		{
			try{
				if(pstmt!=null)pstmt.close();
			}catch(Exception ex){}
		}
		return false;
	}
		//�۾������� Ȯ��
	public boolean isDiaryWriter(int num,String id){
		String diary_write_sql="select * from diary where diary_num=?";
		
		try
		{
			pstmt=con.prepareStatement(diary_write_sql);
			pstmt.setInt(1, num);
			rs=pstmt.executeQuery();
			rs.next();		
			if(id.equals(rs.getString("diary_id"))){
				return true;
			}
		}
		catch(SQLException ex){
			System.out.println("isDiaryWriter����:"+ex);
		}
		return false;
	}
	//�޷� �����
	public List getCalendar(String year, String month, String id){
		List list=new ArrayList();
		try
		{
			String date = year+"�� "+month+"��%";
			pstmt=con.prepareStatement("select diary_num, substr(diary_subject,1,4), writedate from diary where writedate like ? and diary_id=? and diary_share is null order by writedate desc");
			pstmt.setString(1, date); 
			pstmt.setString(2, id);
			rs=pstmt.executeQuery();
			
			while(rs.next())
			{
				DiaryBean diarydata=new DiaryBean();
				
				diarydata.setDiary_num(rs.getInt("diary_num"));
				diarydata.setDiary_subject(rs.getString("substr(diary_subject,1,4)"));
				diarydata.setWritedate(rs.getString("writedate"));
				list.add(diarydata);
			}
			
			return list;
		}
		catch(Exception ex)
		{
			System.out.println("getCalendar ����:"+ex);
		}
		finally
		{
			close(rs,pstmt);
		}
		return null;
	}
	//���� �� ���
	public boolean diaryShareInsert(DiaryBean diarydata){
		int num=0;
		String sql="";
		int result=0;
		
		try
		{
			pstmt=con.prepareStatement("select max(diary_num) from diary");
			
			rs=pstmt.executeQuery();
			
			if(rs.next())
				num=rs.getInt(1)+1;
			else
				num=1;
			diarydata.setDiary_num(num);
			sql=
				"insert into diary(diary_num, diary_id, diary_name, diary_type,";
			sql+="diary_subject, diary_content, diary_file,"+
					"diary_weather, diary_location, writedate, diary_share, diary_sharename)values(?,?,?,?,?,?,?,?,?,?,?,?)";
			
			pstmt=con.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.setString(2, diarydata.getDiary_id());
			pstmt.setString(3, diarydata.getDiary_name());
			pstmt.setString(4, diarydata.getDiary_type());
			pstmt.setString(5, diarydata.getDiary_subject());
			pstmt.setString(6, diarydata.getDiary_content());
			pstmt.setString(7, diarydata.getDiary_file());
			pstmt.setString(8, diarydata.getDiary_weather());
			pstmt.setString(9, diarydata.getDiary_location());
			pstmt.setString(10,diarydata.getWritedate());
			pstmt.setString(11,diarydata.getDiary_share());
			pstmt.setString(12,diarydata.getDiary_sharename());

			result=pstmt.executeUpdate();
			if(result==0)
				return false;
			
			return true;
		}
		catch(Exception ex){
			System.out.println("diaryShareInsert ����:"+ex);
		}
		finally
		{
			close(rs,pstmt);
		}
		return false;
	}
	//���� ���̾ �� �� ����
	public DiaryBean getShareDetail(int diary_num)throws Exception{
		DiaryBean diarydata=null;
		try
		{
			pstmt=con.prepareStatement("select * from diary where diary_num=?");
			
			pstmt.setInt(1, diary_num);
			
			rs=pstmt.executeQuery();
			
			if(rs.next())
			{
				diarydata=new DiaryBean();
				
				diarydata.setDiary_num(rs.getInt("diary_num"));
				diarydata.setDiary_id(rs.getString("diary_id"));
				diarydata.setDiary_name(rs.getString("diary_name"));
				diarydata.setDiary_type(rs.getString("diary_type"));
				diarydata.setDiary_subject(rs.getString("diary_subject"));
				diarydata.setDiary_content(rs.getString("diary_content"));
				diarydata.setDiary_file(rs.getString("diary_file"));
				diarydata.setDiary_weather(rs.getString("diary_weather"));
				diarydata.setDiary_location(rs.getString("diary_location"));
				diarydata.setWritedate(rs.getString("writedate"));
				diarydata.setDiary_share(rs.getString("diary_share"));
				diarydata.setDiary_sharename(rs.getString("diary_sharename"));
			}
			return diarydata;
		}
		catch(Exception ex)
		{
			System.out.println("getShareDetail ����:"+ex);
		}
		finally
		{
			close(rs,pstmt);
		}
		return null;
	}
	//ȸ��Ż��� �� ��ü ����
	public boolean diaryAllDelete(String id){
		String diary_delete_sql="delete from diary where diary_id=?";
		int result=0;
		try
		{
			pstmt=con.prepareStatement(diary_delete_sql);
			pstmt.setString(1, id);
			result=pstmt.executeUpdate();
			if(result==0)
				return false;
			return true;
		}
		catch(Exception ex){
			System.out.println("diaryAllDelete����:"+ex);
			
		}
		finally
		{
			try{
				if(pstmt!=null)pstmt.close();
			}catch(Exception ex){}
		}
		return false;
	}

}
