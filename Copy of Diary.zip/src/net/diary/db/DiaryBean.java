package net.diary.db;

public class DiaryBean {
	
	private int diary_num;			//�۹�ȣ
	private String diary_id;		//���̵�
	private String diary_name;		//�̸�
	private String diary_type;		//������
	private String diary_subject;	//������
	private String diary_content;	//�۳���
	private String diary_file;		//÷������
	private String diary_weather;	//����
	private String diary_location;	//���
	private String writedate;		//�ۼ���
	private String diary_share;		//���� Ű
	private String diary_sharename; //���� �� �۹� �̸�
	
	public int getDiary_num() {
		return diary_num;
	}
	public void setDiary_num(int diary_num) {
		this.diary_num = diary_num;
	}
	public String getDiary_id() {
		return diary_id;
	}
	public void setDiary_id(String diary_id) {
		this.diary_id = diary_id;
	}
	public String getDiary_name() {
		return diary_name;
	}
	public void setDiary_name(String diary_name) {
		this.diary_name = diary_name;
	}
	public String getDiary_type() {
		return diary_type;
	}
	public void setDiary_type(String diary_type) {
		this.diary_type = diary_type;
	}
	public String getDiary_subject() {
		return diary_subject;
	}
	public void setDiary_subject(String diary_subject) {
		this.diary_subject = diary_subject;
	}
	public String getDiary_content() {
		return diary_content;
	}
	public void setDiary_content(String diary_content) {
		this.diary_content = diary_content;
	}
	public String getDiary_file() {
		return diary_file;
	}
	public void setDiary_file(String diary_file) {
		this.diary_file = diary_file;
	}
	public String getWritedate() {
		return writedate;
	}
	public void setWritedate(String writedate) {
		this.writedate = writedate;
	}
	public String getDiary_weather() {
		return diary_weather;
	}
	public void setDiary_weather(String diary_weather) {
		this.diary_weather = diary_weather;
	}
	public String getDiary_location() {
		return diary_location;
	}
	public void setDiary_location(String diary_location) {
		this.diary_location = diary_location;
	}
	public String getDiary_share() {
		return diary_share;
	}
	public void setDiary_share(String diary_share) {
		this.diary_share = diary_share;
	}
	public String getDiary_sharename() {
		return diary_sharename;
	}
	public void setDiary_sharename(String diary_sharename) {
		this.diary_sharename = diary_sharename;
	}
	


}
